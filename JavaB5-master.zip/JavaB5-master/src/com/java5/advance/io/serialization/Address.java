package com.java5.advance.io.serialization;

import java.io.Serializable;

public class Address {
	
	int pinCode;

}

package com.java5.advance.io.serialization;

public class CollegeStudent extends Student{

	public CollegeStudent(int id, String name) {
		super(id, name);
		// TODO Auto-generated constructor stub
	}

}

package com.java5.revision;

class Main {// Source code

	public static void main(String args[]) {

		System.out.println("Hello World");
	}

}
package com.javab5.java.static_concept;

import java.util.Scanner;

public class Xerox {
	
	static Scanner sc;
	static Copier c;

}

class Copier {
	
}

package com.javab5.java.oops.exception_handling;

public class UsingThrowKwyword {
	public static void main(String[] args) {
		int x =8;
		if(x%2==0)
			throw new ArithmeticException();

	}
}

package com.javab5.java.oops.exception_handling;

public class DEH {

	public static void main(String[] args) {
		System.out.println(9/0);//DEH

	}

}

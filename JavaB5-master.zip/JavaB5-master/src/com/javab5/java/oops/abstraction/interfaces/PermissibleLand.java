package com.javab5.java.oops.abstraction.interfaces;

public interface PermissibleLand {
	
	 boolean takePermission();

}

package com.javab5.java.oops.abstraction.interfaces;

public class BowlingAlley {

	int getTicket() {
		return 2;
	}
}

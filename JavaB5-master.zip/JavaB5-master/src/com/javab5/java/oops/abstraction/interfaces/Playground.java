package com.javab5.java.oops.abstraction.interfaces;

public interface Playground {

	void play();

}

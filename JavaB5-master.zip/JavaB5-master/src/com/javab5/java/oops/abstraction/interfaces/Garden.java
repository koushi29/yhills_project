package com.javab5.java.oops.abstraction.interfaces;


//class extends a class
//class implements interface
//interface can extend more than one interfcaes
//class can extend a class and implement more than one interfaces
public interface Garden extends Playground,PermissibleLand{

	boolean gardenVisit();
}

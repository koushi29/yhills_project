package com.javab5.java.oops.final_keyword;

public class MathConstants {

	// Final keyword can be used to create constants
	static final float PI = 3.14159f;
	static final float VALUE_OF_EXPONENT = 2.73f;

}

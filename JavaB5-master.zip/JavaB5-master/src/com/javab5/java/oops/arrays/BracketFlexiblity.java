package com.javab5.java.oops.arrays;

public class BracketFlexiblity {

	public static void main(String[] args) {

		int x;
		int y = 5;
		int z = 6;

		int m, n = 5, o = 6, primes[] = { 2, 3, 5, 7, 11 };

		primes[4] = 73;
		int[] nums = { 5, 676, 44, 66, 7 };// declaring and initializing at the same time
		// len = 5

	}

}

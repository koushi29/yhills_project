package com.javab5.java.oops.arrays;

public class Toy {

	String toyType;
	boolean isChildSafe;
	String color;
}

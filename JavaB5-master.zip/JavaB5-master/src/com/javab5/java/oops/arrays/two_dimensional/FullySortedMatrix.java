package com.javab5.java.oops.arrays.two_dimensional;

public class FullySortedMatrix {

	private void msin() {

		int[][] mat = {

				{ 4, 6, 9 }, { 12, 13, 18 }, { 20, 28, 100 } };// Fully Sorted Matrix

//		Search a element in a fully sorted matrix
	}
}

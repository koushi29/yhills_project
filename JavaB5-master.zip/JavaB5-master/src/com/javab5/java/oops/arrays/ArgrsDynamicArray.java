package com.javab5.java.oops.arrays;

public class ArgrsDynamicArray {

	public static void main(String...suman) {
		System.out.println(suman.length);// 0
		System.out.println(suman[0]);

	}

}

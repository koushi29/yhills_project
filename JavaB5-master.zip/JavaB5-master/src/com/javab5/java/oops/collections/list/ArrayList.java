package com.javab5.java.oops.collections.list;
//package com.javab5.java.oops.collections;
//
// class ArrayList {
//
//	public static void main(String[] args) {
//
//		ArrayList a1 = new ArrayList();
//		java.util.ArrayList a2 = new java.util.ArrayList();// absolute path
//
////		System.out.println(a1.);
//	}
//
//}

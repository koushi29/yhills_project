package com.javab5.java.oops.elevator;


public enum Direction {
    UP,
    DOWN,
    IDLE
}
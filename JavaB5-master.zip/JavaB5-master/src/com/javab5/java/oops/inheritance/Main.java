package com.javab5.java.oops.inheritance;

public class Main {

	public static void main(String[] args) {
//		IPLPlayer p1 = new IPLPlayer(10000, false, 10,8);
		IPLPlayer p1 = new IPLPlayer("Watson", 78, 6, "AUS", 9097, true, 89, 5);
		System.out.println(p1.name);
		System.out.println(p1);
		p1.sayMyName();
		

	}

}

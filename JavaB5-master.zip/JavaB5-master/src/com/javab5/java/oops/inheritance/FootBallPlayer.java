package com.javab5.java.oops.inheritance;

public class FootBallPlayer extends Player{

	
	private float height;
	private String nationality;
	
	public FootBallPlayer(String name, int weight, float height, String nationality) {
		super(name, weight, height, nationality);
	}

}

package com.javab5.java.oops.inheritance;

public class OverridingExample {// Overriding get resolved in runtime so its called Runtime Polymorphism
	public static void main(String[] args) {
		new O().took();
	}
}

class M {
	int x = 10;

	void took() {
		System.out.println("Talk is cheap. Show me the code");
	}
}

class N extends M {
	int x = 100;
}

class O extends N {
	int x = 1000;

//	talk() is inherited

	@Override // Annotations
	public void took() {// You can use the same visiblity of the parent method or even increase it, But
						// you can never decrease the visibility of a ovreidden method
		System.out.println("I love talking and coding seems boring");
	}

	void see() {// special method to class O
		int x = 5;
		System.out.println(x);// 1000
		System.out.println(this.x);
		System.out.println(super.x);// super can only be used to access immediate parent stuffs
	}
}
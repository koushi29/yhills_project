package com.javab5.java.oops.inheritance;

public class MultiLevelInheritance {

	public static void main(String[] args) {
		new C().see();// 1000 | 100

	}

}

class A {
	int x = 10;
}

class B extends A {
	int x = 100;

}

class C extends B {
	int x = 1000;

	void see() {
		int x = 5;
		System.out.println(x);//1000
		System.out.println(this.x);
		System.out.println(super.x);//super can only be used to access immediate parent stuffs
	}
}
package com.javab5.java.oops.inheritance;

public class TypeCasting {

	public static void main(String[] args) {
		Parent p = new Child();// Upcasting | it happens implictly
		p.care();// Caring too..
//		p.play();

//		Child c = (Child) new Parent();// Downcasting you cannot do implicitly, Even you do explicitly you have to take
		// care of the object
		
		castCheck(p);
		castCheck(new Parent());

	}

	static void castCheck(Parent p) {
		if (p instanceof Child) {
			System.out.println("Downcasting...");
			Child ch = (Child) p;
		} else {
			System.out.println("Downcasting not possible");
		}

	}

}

class Parent {

	void care() {
		System.out.println("Caring ..");
	}
}

class Child extends Parent {
	@Override
	void care() {
		System.out.println("Caring too..");
	}

	void play() {
		System.out.println("Playing..");
	}

}

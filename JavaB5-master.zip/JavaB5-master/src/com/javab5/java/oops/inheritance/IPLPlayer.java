package com.javab5.java.oops.inheritance;

public class IPLPlayer extends Player {//Inheritance can be used to extend the functionality

	int runs;
	boolean isAllRounder;
	int wickets;
	int jerseyNo;//4 + 4 Inherited variables
	
//	public IPLPlayer(int runs, boolean isAllRounder, int wickets, int jerseyNo) {
////		super();
////		this();
//		this.runs = runs;
//		this.isAllRounder = isAllRounder;
//		this.wickets = wickets;
//		this.jerseyNo = jerseyNo;
//	}
	
	
	



	
	public IPLPlayer(String name, int weight, float height, String nationality, int runs, boolean isAllRounder,
			int wickets, int jerseyNo) {
		super(name, weight, height, nationality);
//		System.out.println(super.se);
		this.runs = runs;
		this.isAllRounder = isAllRounder;
		this.wickets = wickets;
		this.jerseyNo = jerseyNo;
	}

	@Override
	public String toString() {
		return "IPLPlayer [runs=" + runs + ", isAllRounder=" + isAllRounder + ", wickets=" + wickets + ", jerseyNo="
				+ jerseyNo + ", toString()=" + super.toString() + "]";
	}

	
	

	

	
	
//	public IPLPlayer(String name, int weight, float height, String nationality) {
//		super(name, weight, height, nationality);
//		// TODO Auto-generated constructor stub
//	}

}

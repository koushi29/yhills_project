package com.javab5.java.oops.inheritance;

public class Player {//Object class

	String name;
	int weight;
	float height;
	String nationality;
	private int secretID;//private entities are not inherited
	
	
	public Player(String name, int weight, float height, String nationality) {
		super();
		System.out.println("Player(parameterized) constructor called");
		this.name = name;
		this.weight = weight;
		this.height = height;
		this.nationality = nationality;
	}


	@Override
	public String toString() {
		return "Player [name=" + name + ", weight=" + weight + ", height=" + height + ", nationality=" + nationality
				+ "]";
	}
	
	void sayMyName() {
		System.out.println("NAME : "+this.name);
	}


//	public Player() {
//		System.out.println("Player() constructor called");
//	}
	
	
	
	
}

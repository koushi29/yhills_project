package com.javab5.java.oops.inheritance;

public class StaticWithInheritance {

	public static void main(String[] args) {
		new C1().see();

	}

}

class P1 {

	static void see() {// class level | Static things can be inherited
		System.out.println("SEEING statically P1");
	}
}

class C1 extends P1 {

//	@Override  | static methods cannot be overrided
	static void see() {// class level | Static things can be inherited
		System.out.println("SEEING statically C1");
		P1.see();
	}

}
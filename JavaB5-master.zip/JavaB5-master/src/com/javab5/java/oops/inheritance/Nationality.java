package com.javab5.java.oops.inheritance;

//CodeReusablity
public class Nationality {//Object
	
	String nameOfNation;
	boolean hasPaasport;

}

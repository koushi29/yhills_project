package com.javab5.java.oops.inheritance;

 final class Pikachu {//final classes cannot be inherited

	String pokeMonName;
	String strengthType;
	int evolutionStage;

}

package com.javab5.java.oops.map;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapExample {

	public static void main(String[] args) {

		HashMap<Integer, String> mapOfSTudents = new HashMap<>(20,0.75f);// K:V | K --> immutable and non duplicates

//		---i/p (K)--->  hash fn  --o\p--->

		// Hashing fn (Hash fn) on the Key
		// searching is very fast is map
		mapOfSTudents.put(3, "John");
		mapOfSTudents.put(1, "Emiilie");
		mapOfSTudents.put(5, "Mary");
		mapOfSTudents.put(0, "Tom");
		mapOfSTudents.put(3, "Hamie");
		mapOfSTudents.put(8, "Tom");

		System.out.println(mapOfSTudents);

		ArrayList<Integer> listOfNums = new ArrayList<>();
		listOfNums.add(4);
		listOfNums.add(44);
		listOfNums.add(14);
		listOfNums.add(435);
		listOfNums.add(6);
		listOfNums.add(4);
		listOfNums.add(14);
		listOfNums.add(24);
		listOfNums.add(14);
		listOfNums.add(0);
		listOfNums.add(-7);
		listOfNums.add(7);

		HashMap<Integer, Integer> freqTable = new HashMap<>();

		for (Integer num : listOfNums) {
			if (freqTable.containsKey(num)) {
				int x = freqTable.get(num) + 1;
				freqTable.put(num, x);
			} else {
				freqTable.put(num, 1);
			}
		}

		System.out.println(freqTable);

		Set<Entry<Integer, Integer>> entrySet = freqTable.entrySet();
//		
		for (Entry<Integer, Integer> entry : freqTable.entrySet()) {
			System.out.println(entry + " -> " + entry.getKey() + " : " + entry.getValue());
		}

		Set<Integer> keySet = freqTable.keySet();

		// Open a stream in HashMap
		freqTable.entrySet().stream().forEach(System.out::print);//indirect streaming

	}

}

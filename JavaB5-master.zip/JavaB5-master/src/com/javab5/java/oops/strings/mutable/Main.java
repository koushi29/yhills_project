package com.javab5.java.oops.strings.mutable;

public class Main {

	public static void main(String[] args) {
		StringBuffer stringBuffer = new StringBuffer();
		StringBuilder stringBuilder = new StringBuilder();

	}
}

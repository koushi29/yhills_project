package com.javab5.java.oops.elevator_project;
public enum Direction {
    UP,
    DOWN,
    IDLE
}

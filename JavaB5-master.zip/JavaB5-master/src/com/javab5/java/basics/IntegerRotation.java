package com.javab5.java.basics;

public class IntegerRotation {

//	-Infinite      0  			+Infinity
	public static void main(String[] args) {
		int x = Integer.MAX_VALUE + 5;//
		System.out.println(x);

		int y = Integer.MIN_VALUE;
		System.out.println(y);
		--y;
		System.out.println(y);
	}
}

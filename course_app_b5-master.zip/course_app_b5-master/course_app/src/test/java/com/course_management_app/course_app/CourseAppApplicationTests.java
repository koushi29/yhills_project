package com.course_management_app.course_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseAppApplicationTests {

	@Test
	void contextLoads() {
	}

}

# course_app_b5
Spring Boot App Course Management App using Spring Data Rest Service
